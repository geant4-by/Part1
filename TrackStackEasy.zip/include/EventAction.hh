#pragma once

#include <G4UserEventAction.hh>
#include <G4SystemOfUnits.hh>
#include <G4Event.hh>
#include <G4EventManager.hh>

class EventAction : public G4UserEventAction
{
    public:
        EventAction(std::ofstream& ofsa);
        virtual ~EventAction();

        void BeginOfEventAction(const G4Event*);
        void EndOfEventAction(const G4Event*);

        void AddE(G4double dE);
        void StepLengthCounter(G4double SL); // функция приема значений (из шагов)

    private:
        std::ofstream& f_event;
        int SLcounter;
        G4double Esum;
};
