#pragma once

#include <G4VUserActionInitialization.hh>
#include "PrimaryPart.hh"
#include "EventAction.hh"
#include "StepAction.hh"

class Action : public G4VUserActionInitialization
{
    public:
        Action(std::ofstream& ofsa);
        virtual ~Action();
        virtual void Build() const;

    private:
        std::ofstream& f_act;
};
