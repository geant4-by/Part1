#include "StepAction.hh"

// Обработчик событий на уровне Step - просчет отдельного шага/акта взаимодействия

StepAction::StepAction(std::ofstream& ofsa, EventAction* eventAction)
: f_step(ofsa),
  fEventAction(eventAction)
{
    f_step << "Hi from Step!" << std::endl;
}

StepAction::~StepAction()
{
    f_step << "Bye from Step!" << std::endl;
}

void StepAction::UserSteppingAction(const G4Step* step) 
{
    G4StepPoint* point1 = step->GetPreStepPoint();  
    G4StepPoint* point2 = step->GetPostStepPoint();

    G4ThreeVector vect1, vect2;
    vect1 = point1->GetPosition();
    vect2 = point2->GetPosition();  
    G4cout << "X1 = " << vect1[0] / mm << " Y1 = " << vect1[1] / mm << " Z1 = " << vect1[2] / mm << G4endl;
    G4cout << "X2 = " << vect2[0] / mm << " Y2 = " << vect2[1] / mm << " Z2 = " << vect2[2] / mm << G4endl;
    
    G4double Ekin1, Ekin2;
    Ekin1 = point1->GetKineticEnergy();
    Ekin2 = point2->GetKineticEnergy();
    
    G4double StepLength = step->GetStepLength(); // извлекаем инфу из шага
    fEventAction->StepLengthCounter(StepLength); // передаем инфу в другой класс (на уровень выше)
    G4double edep = step->GetTotalEnergyDeposit();
    fEventAction->AddE(edep);
    
    G4cout << step->GetTrack()->GetDynamicParticle()->GetDefinition()->GetParticleName()
           << " : E1 = " << Ekin1 / MeV
           << " : E2 = " << Ekin2 / MeV
           << " : step_length = " << StepLength / mm << "\n" << G4endl;
}
