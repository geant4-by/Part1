#include "PrimaryPart.hh"

PrimaryPart::PrimaryPart(std::ofstream& ofsa)
: f_prim(ofsa)
{
    f_prim << std::setw(12) << "Hi from PrimaryPart!" << std::endl;
    fParticleGun = new G4ParticleGun(1);
    fParticleGun->SetParticleDefinition(G4Proton::ProtonDefinition());
    // fParticleGun->SetParticleDefinition(G4Neutron::NeutronDefinition());
    fParticleGun->SetParticleEnergy(1000. * MeV);
}

PrimaryPart::~PrimaryPart() 
{
    f_prim << std::setw(12) << "Bye from PrimaryPart!" << std::endl;
}

// генерация излучения
void PrimaryPart::GeneratePrimaries(G4Event* anEvent) 
{
    // fParticleGun->SetParticlePosition(G4ThreeVector(0, 0, 0));
    fParticleGun->SetParticlePosition(G4ThreeVector(0 * mm , 0 * mm, -21. * cm));
    fParticleGun->SetParticleMomentumDirection(G4ThreeVector(0, 0, 1));
    fParticleGun->GeneratePrimaryVertex(anEvent); 
}
