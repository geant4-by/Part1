#pragma once

#include <G4VUserDetectorConstruction.hh>
#include <G4SystemOfUnits.hh>

#include <G4GeometryManager.hh>
#include <G4SolidStore.hh>
#include <G4LogicalVolumeStore.hh>
#include <G4PhysicalVolumeStore.hh>

#include <G4NistManager.hh>

#include <G4Box.hh>
#include <G4Tubs.hh>
#include <G4PVPlacement.hh>

#include <G4VisAttributes.hh>
#include <G4UserLimits.hh>

class Geometry : public G4VUserDetectorConstruction
{
    public:
        Geometry(std::ofstream& ofsa);
        virtual ~Geometry() override;
        virtual G4VPhysicalVolume *Construct() override;

    private:
        G4Box*              world_box;
        G4LogicalVolume*    world_log;    
        G4VPhysicalVolume*  world_pvpl;

        G4Tubs*             DE1_tubs;
        G4LogicalVolume*    DE1_log;
        G4VPhysicalVolume*  DE1_pvpl;

        std::ofstream& f_geom;
};
