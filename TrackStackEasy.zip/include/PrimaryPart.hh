#pragma once

#include <G4VUserPrimaryGeneratorAction.hh>
#include <G4ParticleGun.hh>
#include <G4Proton.hh>
#include <G4Neutron.hh>
#include <G4Gamma.hh>
#include <G4SystemOfUnits.hh>
#include <fstream>

class PrimaryPart : public G4VUserPrimaryGeneratorAction
{
    public:
        PrimaryPart(std::ofstream& ofsa);
        ~PrimaryPart();
        virtual void GeneratePrimaries(G4Event* anEvent);
        G4ParticleGun* GetParticleGun() { return fParticleGun; }

    private:
        std::ofstream& f_prim;
        G4ParticleGun* fParticleGun;
};
