#include "EventAction.hh"

// Обработчик событий на уровне Event - от начала запуска частицы до ее поглощения

EventAction::EventAction(std::ofstream& ofsa)
: f_event(ofsa)
{
    f_event << "Hi from Event!";
    G4int vl = G4EventManager::GetEventManager()->GetVerboseLevel();
    f_event << " verbose level = " << vl << std::endl;
    SLcounter = 0;
    Esum = 0.;
}

EventAction::~EventAction()
{
    f_event << "Bye from Event!" << std::endl;
}

void EventAction::StepLengthCounter(G4double step_len) 
{
    // описание функции приема значения из шага
    SLcounter++;
    G4cout << "Step N = " << SLcounter << ", Length = " << step_len / mm << G4endl; // debug-инфо
}

void EventAction::AddE(G4double edep)
{
    Esum += edep;
}

void EventAction::BeginOfEventAction(const G4Event* event)
{
    SLcounter = 0; // обнуление счетчика каждый раз при запуске единичного события
    G4cout << "BeginWorks : event_id = " << event->GetEventID() << "\n" << G4endl;
    f_event << "event_id = " << event->GetEventID() << std::endl;
}

void EventAction::EndOfEventAction(const G4Event* event)
{
    f_event << "Esum = " << Esum << "\n" << std::endl;
    G4cout << "EndWorks : event_id = " << event->GetEventID() << G4endl;
    SLcounter = 0;
    Esum = 0.;
}
