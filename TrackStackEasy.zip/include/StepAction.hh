#pragma once

#include <G4UserSteppingAction.hh>
#include <G4Step.hh>
#include "EventAction.hh" // подключаем библиотеку с используемым счетчиком

class StepAction : public G4UserSteppingAction
{
    public:
        StepAction(std::ofstream& ofsa, EventAction* eventAction);
        ~StepAction();
        void UserSteppingAction(const G4Step*);

    private:
        std::ofstream& f_step;
        EventAction* fEventAction;
};
