#include "Action.hh"

Action::Action(std::ofstream& ofsa)
: f_act(ofsa)
{
    f_act << "Hi from Action!" << std::endl;
}

Action::~Action() 
{
    f_act << "Bye from Action!" << std::endl;
}

// подключение файлов, начало их выполнения
void Action::Build()const 
{
    SetUserAction(new PrimaryPart(f_act));
    EventAction* eventAction = new EventAction(f_act);
    SetUserAction(eventAction);
    SetUserAction(new StepAction(f_act, eventAction));
}
