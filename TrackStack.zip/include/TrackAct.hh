
#include <G4SystemOfUnits.hh>
#include <G4UserTrackingAction.hh>
#include <G4TrackingManager.hh>
#include <G4Event.hh>
#include <iomanip>

class TrackAct : public G4UserTrackingAction 
{
 public:
        std::ofstream*f_track;
        G4int counterTracks;

	TrackAct(std::ofstream&);
	~TrackAct();

        void PreUserTrackingAction(const G4Track*);
        void PostUserTrackingAction(const G4Track*);
};
