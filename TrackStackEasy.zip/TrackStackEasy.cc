#include <G4GlobalConfig.hh>

#include <G4RunManager.hh>
#include <G4UImanager.hh>
#include <G4VisManager.hh>

#include <G4UIExecutive.hh>
#include <G4VisExecutive.hh>

#include "Geometry.hh"
#include <QBBC.hh>
#include <G4StepLimiterPhysics.hh>
#include "Action.hh"

#include <iostream>

int main(int argc, char** argv)
{
    std::ofstream fout("output.txt");
    fout << std::setw(12) << "Hi from main!" << std::endl;

    G4RunManager* runManager = new G4RunManager();
    runManager->SetUserInitialization(new Geometry(fout));
    G4VModularPhysicsList* physicsList = new QBBC(0); // verbose level 0
    physicsList->RegisterPhysics(new G4StepLimiterPhysics());
    runManager->SetUserInitialization(physicsList);
    runManager->SetUserInitialization(new Action(fout));
    runManager->Initialize();

    // initialize visualization
    G4VisManager* visManager = new G4VisExecutive();
    visManager->Initialize();
    G4UImanager* UImanager = G4UImanager::GetUIpointer();

    if (argc != 1) {
        // batch mode
        G4String command = "/control/execute ";
        G4String fileName = argv[1];
        UImanager->ApplyCommand(command + fileName);
    } else {
        // interactive mode : define UI session
        // here we can redefine win32/qt interface
        G4UIExecutive *ui = new G4UIExecutive(argc, argv, "qt");
        UImanager->ApplyCommand("/control/execute vis.mac");
        ui->SessionStart(); // and this two
        delete ui;
    }

    delete runManager;
    delete visManager;

    fout << std::setw(12) << "Bye from main!" << std::endl;
    fout.close();

    return 0;
}
